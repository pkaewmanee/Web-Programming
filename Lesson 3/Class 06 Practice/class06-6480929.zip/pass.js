// pass.js
//   Register the event handlers for pass.html
     
function showInfo(u, p) {
    // Displaying the username and password in a popup window
    alert("Username: " + u + "\nPassword: " + p);
}